Traductor menu contextual (Chrome Extension)
============================================

- Selecciona el texto y pulsa el botón derecho para traducirlo.

Copyright 2012 Edgar Miró
License: BSD

Esta extensión está disponible en Chrome Web Store:
https://chrome.google.com/webstore/detail/lonkkphbooogeflneiinlchdpbjmipbn

Fork del proyecto de Brandon Thomson:
https://github.com/bthomson/chromeGoogleTranslate